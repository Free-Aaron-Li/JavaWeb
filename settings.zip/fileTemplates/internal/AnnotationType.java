#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

/**
 * @projectName:    ${PROJECT_NAME} 
 * @className:      ${NAME}
 * @author:     AaronLi
 * @description:    nothingd
 * @date:    ${DATE} ${TIME}
 * @version:    JDK17
 */ 
 
public @interface ${NAME} {
}
