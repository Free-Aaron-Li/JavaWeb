#parse("File Header.java")

/**
 * @projectName:    ${PROJECT_NAME} 
 * @className:      ${NAME}
 * @author:     AaronLi
 * @description:    nothing
 * @date:    ${DATE} ${TIME}
 * @version:    JDK17
 */ 
 
module #[[$MODULE_NAME$]]# {
}